package ejecutar;

/**
 *
 * @author Joel García
 */
import ventana_login.FrmLogin;

public class SistemaMain {
    
    public static void main (String[] args){
        
   
        
        
        
    }
    
}
