package ventana_principal;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import crudtablas.CityCRUD;
import crudtablas.CustomerCRUD;
import crudtablas.ManufacturerCRUD;
import crudtablas.CustomerTransactionCRUD;
import crudtablas.ManufacturerTransactionCRUD;
import ventana_login.FrmLogin;
import static java.awt.Color.WHITE;
import java.io.File;
import java.awt.Desktop;

/**
 * Principal - Ventana principal del sistema
 * Recibe el rol del usuario desde el Login
 * @author Joel García
 */
public class Principal extends JFrame {

    private static final Color C_DARK   = new Color(0x05, 0x09, 0x43);
    private static final Color C_BLUE   = new Color(0x0E, 0x1A, 0xC4);
    private static final Color C_PURPLE = new Color(0x66, 0x70, 0xF4);
    private static final Color C_YELLOW = new Color(0xFB, 0xF7, 0x32);

    private final String rol;
 
    public Principal(String rol) {
        this.rol = rol;
        initUI();
    }

    private void initUI() {
        setTitle("Rolling Thunder Bicycles — " + rol);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel root = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(C_DARK);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        // ── Barra superior ────────────────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(C_BLUE);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        topBar.setPreferredSize(new Dimension(0, 50));
        topBar.setBorder(new EmptyBorder(0, 20, 0, 20));

        JLabel lblSistema = new JLabel("Rolling Thunder Bicycles");
        lblSistema.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblSistema.setForeground(Color.WHITE);

        // Badge del rol
        String badgeText = rol.equals("ADMIN") ? "Admin" : "Consultante";
        Color badgeColor = rol.equals("ADMIN") ? C_YELLOW : C_PURPLE;
        Color badgeTextColor = rol.equals("ADMIN") ? C_DARK : Color.WHITE;

        JLabel lblRol = new JLabel(badgeText) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(badgeColor);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        lblRol.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblRol.setForeground(badgeTextColor);
        lblRol.setBorder(new EmptyBorder(4, 12, 4, 12));
        lblRol.setOpaque(false);

        JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        rightBar.setOpaque(false);
        rightBar.add(lblRol);
        
            JButton btnCerrarSesion = new JButton("Cerrar Sesión");

            btnCerrarSesion.setFocusPainted(false);
            btnCerrarSesion.setCursor(new Cursor(Cursor.HAND_CURSOR));

            btnCerrarSesion.addActionListener(e -> {

                JOptionPane.showMessageDialog(
                        this,
                        "Sesión cerrada correctamente"
                );

                dispose();

                new FrmLogin().setVisible(true);

            });

            rightBar.add(btnCerrarSesion);
        
           /* =====================================================
               MENU BAR
            ===================================================== */

            JMenuBar menuBar = new JMenuBar();

            menuBar.setBackground(C_BLUE);
            menuBar.setBorder(null);
        

            /* =====================================================
               MENU TABLAS
            ===================================================== */

           JMenu menuTablas = new JMenu("Tablas");
           menuTablas.setForeground(WHITE);

           JMenuItem crudCity = new JMenuItem("CRUD - City");
           JMenuItem crudCustomer = new JMenuItem("CRUD - Customer");
           JMenuItem crudManufacturer = new JMenuItem("CRUD - Manufacturer");
           JMenuItem crudCustomerTransaction = new JMenuItem("CRUD - CustomerTransaction");
           JMenuItem crudManufacturerTransaction = new JMenuItem("CRUD - ManufacturerTransaction");
           
             crudCity.addActionListener(e -> {
                     new CityCRUD(rol).setVisible(true);
             });

             crudCustomer.addActionListener(e -> {
                 new CustomerCRUD(rol).setVisible(true);
             });

             crudManufacturer.addActionListener(e -> {
                 new ManufacturerCRUD(rol).setVisible(true);
             });

             crudCustomerTransaction.addActionListener(e -> {
                 new CustomerTransactionCRUD(rol).setVisible(true);
             });

             crudManufacturerTransaction.addActionListener(e -> {
                 new ManufacturerTransactionCRUD(rol).setVisible(true);
             });
             
            menuTablas.add(crudCity);
            menuTablas.add(crudCustomer);
            menuTablas.add(crudManufacturer);
            menuTablas.add(crudCustomerTransaction);
            menuTablas.add(crudManufacturerTransaction);
            
            /* =====================================================
               MENU AYUDA
            ===================================================== */

            JMenu menuAyuda = new JMenu("Ayuda");
            menuAyuda.setForeground(WHITE);
            JMenuItem manualUsuario = new JMenuItem("Manual de Usuario");

            /* =====================================================
               MANUAL DE USUARIO
            ===================================================== */

            manualUsuario.addActionListener(e -> {

                try {

                    File archivo = new File("src/manual/manualUsuario.pdf");

                    Desktop.getDesktop().open(archivo);

                } catch (Exception ex) {

                    JOptionPane.showMessageDialog(null,
                            "No se pudo abrir el manual");

                }

            });

            /* =====================================================
               AGREGAR ITEMS Y MENUS
            ===================================================== */

            menuAyuda.add(manualUsuario);

            menuBar.add(menuTablas);
            menuBar.add(menuAyuda);

        topBar.add(lblSistema, BorderLayout.WEST);
        topBar.add(menuBar, BorderLayout.CENTER);
        topBar.add(rightBar, BorderLayout.EAST);

        // ── Centro (placeholder) ──────────────────────────────────────────────
        JPanel center = new JPanel(new GridBagLayout());
        center.setOpaque(false);

        JLabel lblBienvenido = new JLabel("Bienvenido, " + rol.charAt(0) + rol.substring(1).toLowerCase());
        lblBienvenido.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblBienvenido.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Aquí irá el contenido principal del sistema.");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(C_PURPLE);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);
        lblBienvenido.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(lblBienvenido);
        content.add(Box.createVerticalStrut(10));
        content.add(lblSub);

        // Mensaje de permisos
        if (rol.equals("CONSULTANTE")) {
            JLabel lblPerm = new JLabel("Acceso limitado — modo consulta");
            lblPerm.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblPerm.setForeground(C_PURPLE);
            lblPerm.setAlignmentX(Component.CENTER_ALIGNMENT);
            content.add(Box.createVerticalStrut(6));
            content.add(lblPerm);
        }

        center.add(content);

        root.add(topBar, BorderLayout.NORTH);
        root.add(center, BorderLayout.CENTER);
        setContentPane(root);
    }



   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 706, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 428, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


  


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}