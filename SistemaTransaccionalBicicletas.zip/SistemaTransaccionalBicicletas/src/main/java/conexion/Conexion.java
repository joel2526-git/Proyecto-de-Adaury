package conexion;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Joel García
 */
public class Conexion {
    
      public static Connection conectar(){
        
        Connection con = null;
        try {
            String url = "jdbc:mysql://localhost:3306/rolling_thunder_bicycles";
            String user = "root";
            String password = "";
            con = DriverManager.getConnection(url, user, password);
            
        } catch (Exception e){ 
            
            System.out.println("e.getMessage");
            
        }
      
     return con;
    }
    
}
