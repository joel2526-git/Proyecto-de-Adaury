package ventana_login;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import ventana_principal.Principal;


/**
 *
 * @author Joel García
 */

public class FrmLogin extends javax.swing.JFrame {
    
    private static final String[][] USUARIOS = {
        
    {"admin", "admin123", "ADMIN"},
    {"consultante", "consult123", "CONSULTANTE"},
    {"prueba", "prueba123", "PRUEBA"}
            
    };  

    public FrmLogin() {
        initComponents();
        
    this.setTitle("Iniciar sesión");
    
    txtUsuario.putClientProperty(
        "FlatLaf.style",
        "arc:20"
    );

    txtPassword.putClientProperty(
        "FlatLaf.style",
        "arc:20"
            

    );


       
        //Metodo para aplicarle estilos diferentes a un objeto en especifico
        InitStyles();
    }

            private void InitStyles() {
                
                //Boton iniciar sesión
                UIManager.put("btnIniciarSesion.arc", 25 );
                


                
            }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        panelIzquierdo = new javax.swing.JPanel();
        nombreEmpresa = new javax.swing.JLabel();
        descEmpresa = new javax.swing.JLabel();
        lblIcono = new javax.swing.JLabel();
        labelRoles = new javax.swing.JLabel();
        rolAdmin = new javax.swing.JLabel();
        rolUsuario = new javax.swing.JLabel();
        panelDerecho = new javax.swing.JPanel();
        txtUsuario = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        btnIniciarSesion = new javax.swing.JButton();
        labelPassword = new javax.swing.JLabel();
        labelUsuario = new javax.swing.JLabel();
        labelSubtitulo = new javax.swing.JLabel();
        labelTitulo = new javax.swing.JLabel();
        lblError = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        background.setBackground(new java.awt.Color(255, 255, 255));

        panelIzquierdo.setBackground(new java.awt.Color(14, 26, 196));
        panelIzquierdo.setPreferredSize(new java.awt.Dimension(270, 640));

        nombreEmpresa.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        nombreEmpresa.setForeground(new java.awt.Color(251, 247, 50));
        nombreEmpresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nombreEmpresa.setText("Thunder Bikes");

        descEmpresa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        descEmpresa.setForeground(new java.awt.Color(102, 112, 244));
        descEmpresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        descEmpresa.setText("<html><center>Sistema de gestión de las<br> transacciones de los clientes y fabricantes</center>");
        descEmpresa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        lblIcono.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblIcono.setIcon(new javax.swing.ImageIcon("C:\\Users\\Joel García\\Downloads\\image3.png")); // NOI18N

        labelRoles.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelRoles.setForeground(new java.awt.Color(0, 153, 204));
        labelRoles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelRoles.setText("Roles de Usuario");

        rolAdmin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        rolAdmin.setForeground(new java.awt.Color(251, 247, 50));
        rolAdmin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        rolAdmin.setText("● Admin");

        rolUsuario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        rolUsuario.setForeground(new java.awt.Color(102, 112, 244));
        rolUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        rolUsuario.setText("● Consultante");

        javax.swing.GroupLayout panelIzquierdoLayout = new javax.swing.GroupLayout(panelIzquierdo);
        panelIzquierdo.setLayout(panelIzquierdoLayout);
        panelIzquierdoLayout.setHorizontalGroup(
            panelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelIzquierdoLayout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblIcono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(90, 90, 90))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelIzquierdoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rolAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rolUsuario))
                .addGap(118, 118, 118))
            .addGroup(panelIzquierdoLayout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(panelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelIzquierdoLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(nombreEmpresa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(75, 75, 75))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelIzquierdoLayout.createSequentialGroup()
                        .addGroup(panelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(labelRoles, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(descEmpresa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(65, 65, 65))))
        );
        panelIzquierdoLayout.setVerticalGroup(
            panelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelIzquierdoLayout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(lblIcono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nombreEmpresa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(descEmpresa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(26, 26, 26)
                .addComponent(labelRoles, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(rolAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rolUsuario)
                .addGap(171, 171, 171))
        );

        panelDerecho.setBackground(new java.awt.Color(5, 9, 67));

        txtUsuario.setBackground(new java.awt.Color(14, 72, 242));
        txtUsuario.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtUsuario.setForeground(new java.awt.Color(255, 255, 255));
        txtUsuario.setActionCommand("<Not Set>");
        txtUsuario.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });

        txtPassword.setBackground(new java.awt.Color(14, 72, 242));
        txtPassword.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtPassword.setForeground(new java.awt.Color(255, 255, 255));
        txtPassword.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnIniciarSesion.setBackground(new java.awt.Color(251, 247, 50));
        btnIniciarSesion.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnIniciarSesion.setForeground(new java.awt.Color(5, 9, 67));
        btnIniciarSesion.setText("Ingresar al sistema");
        btnIniciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarSesionActionPerformed(evt);
            }
        });

        labelPassword.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelPassword.setForeground(new java.awt.Color(102, 112, 244));
        labelPassword.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelPassword.setText("Contraseña");

        labelUsuario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelUsuario.setForeground(new java.awt.Color(102, 112, 244));
        labelUsuario.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelUsuario.setText("Usuario");

        labelSubtitulo.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        labelSubtitulo.setForeground(new java.awt.Color(102, 112, 244));
        labelSubtitulo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelSubtitulo.setText("Ingresa tus credenciales");

        labelTitulo.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        labelTitulo.setForeground(new java.awt.Color(255, 255, 255));
        labelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelTitulo.setText("Iniciar sesión");

        lblError.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblError.setForeground(new java.awt.Color(255, 0, 0));
        lblError.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout panelDerechoLayout = new javax.swing.GroupLayout(panelDerecho);
        panelDerecho.setLayout(panelDerechoLayout);
        panelDerechoLayout.setHorizontalGroup(
            panelDerechoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDerechoLayout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(panelDerechoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelDerechoLayout.createSequentialGroup()
                        .addComponent(labelPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panelDerechoLayout.createSequentialGroup()
                        .addComponent(labelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelDerechoLayout.createSequentialGroup()
                        .addGroup(panelDerechoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblError, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtUsuario)
                            .addComponent(txtPassword, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnIniciarSesion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDerechoLayout.createSequentialGroup()
                                .addGroup(panelDerechoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(labelSubtitulo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelDerechoLayout.createSequentialGroup()
                                        .addComponent(labelTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(58, 58, 58)))
                                .addGap(80, 80, 80)))
                        .addGap(61, 61, 61))))
        );
        panelDerechoLayout.setVerticalGroup(
            panelDerechoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDerechoLayout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addComponent(labelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelSubtitulo)
                .addGap(18, 18, 18)
                .addComponent(labelUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(labelPassword, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(btnIniciarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblError, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102))
        );

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addComponent(panelIzquierdo, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundLayout.createSequentialGroup()
                .addGap(307, 307, 307)
                .addComponent(panelDerecho, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelDerecho, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelIzquierdo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );

        getContentPane().add(background, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
       

        
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void btnIniciarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarSesionActionPerformed

    String usuario = txtUsuario.getText().trim();
    String password = new String(txtPassword.getPassword()).trim();

    //Validar campos vacíos
    if (usuario.isEmpty() || password.isEmpty()) {

        lblError.setText("Complete todos los campos");
        return;
    }

    //Recorrer usuarios
    for (String[] u : USUARIOS) {

        String user = u[0];
        String pass = u[1];
        String rol = u[2];

        //Validación
        if (user.equalsIgnoreCase(usuario) && pass.equals(password)) {

            //Abrir ventana principal
            Principal principal = new Principal(rol);

            principal.setVisible(true);

            //Cerrar login
            dispose();

            return;
        }
    }

    //Si no coincide el usuario ingresado con uno de los que estan registrados
    lblError.setText("Usuario o contraseña incorrectos");

    txtPassword.setText("");
    txtPassword.requestFocus();

    }//GEN-LAST:event_btnIniciarSesionActionPerformed

    public static void main(String args[]) {
       
        FlatMaterialLighterIJTheme.setup();
        


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmLogin().setVisible(true);
                
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel background;
    private javax.swing.JButton btnIniciarSesion;
    private javax.swing.JLabel descEmpresa;
    private javax.swing.JLabel labelPassword;
    private javax.swing.JLabel labelRoles;
    private javax.swing.JLabel labelSubtitulo;
    private javax.swing.JLabel labelTitulo;
    private javax.swing.JLabel labelUsuario;
    private javax.swing.JLabel lblError;
    private javax.swing.JLabel lblIcono;
    private javax.swing.JLabel nombreEmpresa;
    private javax.swing.JPanel panelDerecho;
    private javax.swing.JPanel panelIzquierdo;
    private javax.swing.JLabel rolAdmin;
    private javax.swing.JLabel rolUsuario;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
