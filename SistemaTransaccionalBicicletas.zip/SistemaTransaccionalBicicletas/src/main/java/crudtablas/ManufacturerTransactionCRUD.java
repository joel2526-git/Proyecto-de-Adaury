/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package crudtablas;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Joel García
 */
public class ManufacturerTransactionCRUD extends javax.swing.JFrame {


    // CONFIRMACION DEL ROL CONSULTANTE
private String rol;

public ManufacturerTransactionCRUD(String rol) {

    initComponents();

    this.rol = rol;

    permisos();

    DefaultTableModel modelo = new DefaultTableModel();
    tablaManufacturerTransaction.setModel(modelo);

}

private void permisos() {

    if (rol.equals("CONSULTANTE")) {

        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);

    }
    
        if(rol.equals("PRUEBA")) {

        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);

    }

}
    /**
     * Creates new form ManufacturerTransactionCRUD
     */
public ManufacturerTransactionCRUD() {
        initComponents();
        
       DefaultTableModel modelo = new DefaultTableModel();
       tablaManufacturerTransaction.setModel(modelo);
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        campoTransactionID = new javax.swing.JLabel();
        campoManufacturerID = new javax.swing.JLabel();
        campoEmployeeID = new javax.swing.JLabel();
        campoTransactionDate = new javax.swing.JLabel();
        campoAmount = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        campoDescription = new javax.swing.JLabel();
        txtTransactionID = new javax.swing.JTextField();
        txtManufacturerID = new javax.swing.JTextField();
        txtEmployeeID = new javax.swing.JTextField();
        txtTransactionDate = new javax.swing.JTextField();
        txtReference = new javax.swing.JTextField();
        txtAmount = new javax.swing.JTextField();
        txtDescription = new javax.swing.JTextField();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaManufacturerTransaction = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Vista de la Tabla");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        campoTransactionID.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoTransactionID.setForeground(new java.awt.Color(0, 0, 0));
        campoTransactionID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        campoTransactionID.setText("TransactionID:");

        campoManufacturerID.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoManufacturerID.setForeground(new java.awt.Color(0, 0, 0));
        campoManufacturerID.setText("ManufacturerID:");

        campoEmployeeID.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoEmployeeID.setForeground(new java.awt.Color(0, 0, 0));
        campoEmployeeID.setText("EmployeeID:");

        campoTransactionDate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoTransactionDate.setForeground(new java.awt.Color(0, 0, 0));
        campoTransactionDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        campoTransactionDate.setText("TransactionDate:");

        campoAmount.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoAmount.setForeground(new java.awt.Color(0, 0, 0));
        campoAmount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        campoAmount.setText("Amount:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Reference:");

        campoDescription.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoDescription.setForeground(new java.awt.Color(0, 0, 0));
        campoDescription.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        campoDescription.setText("Description:");

        txtTransactionID.setBackground(new java.awt.Color(0, 204, 204));

        txtManufacturerID.setBackground(new java.awt.Color(0, 204, 204));

        txtEmployeeID.setBackground(new java.awt.Color(0, 204, 204));

        txtTransactionDate.setBackground(new java.awt.Color(0, 204, 204));

        txtReference.setBackground(new java.awt.Color(0, 204, 204));

        txtAmount.setBackground(new java.awt.Color(0, 204, 204));

        txtDescription.setBackground(new java.awt.Color(0, 204, 204));
        txtDescription.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btnInsertar.setBackground(new java.awt.Color(0, 255, 0));
        btnInsertar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnInsertar.setForeground(new java.awt.Color(0, 0, 0));
        btnInsertar.setText("Insertar");
        btnInsertar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setBackground(new java.awt.Color(255, 255, 0));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModificar.setForeground(new java.awt.Color(0, 0, 0));
        btnModificar.setText("Modificar");
        btnModificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 0, 0));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(0, 0, 0));
        btnEliminar.setText("Eliminar");
        btnEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnBuscar.setBackground(new java.awt.Color(0, 102, 255));
        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 0, 0));
        btnBuscar.setText("Buscar");
        btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnLimpiar.setBackground(new java.awt.Color(255, 0, 255));
        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(0, 0, 0));
        btnLimpiar.setText("Limpiar Búsqueda");
        btnLimpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        tablaManufacturerTransaction.setBackground(new java.awt.Color(0, 153, 204));
        tablaManufacturerTransaction.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablaManufacturerTransaction);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Vista de la Tabla");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(campoTransactionDate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTransactionDate, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(campoTransactionID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTransactionID, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(campoManufacturerID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtManufacturerID, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(campoEmployeeID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(campoAmount)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(campoDescription)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(73, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnInsertar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnModificar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEliminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscar)
                        .addGap(174, 174, 174)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnLimpiar)
                .addGap(272, 272, 272))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(campoTransactionID)
                            .addComponent(txtTransactionID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(campoManufacturerID)
                            .addComponent(txtManufacturerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoEmployeeID)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(campoAmount))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(34, 34, 34))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(campoDescription)
                            .addComponent(txtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoTransactionDate)
                    .addComponent(txtTransactionDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLimpiar)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed

               if (txtManufacturerID.getText().isEmpty() || txtEmployeeID.getText().isEmpty() || txtTransactionDate.getText().isEmpty()
            || txtAmount.getText().isEmpty() || txtReference.getText().isEmpty() || txtDescription.getText().isEmpty()) {

        javax.swing.JOptionPane.showMessageDialog(this, "Campos vacíos, por favor ingrese información");
        return;
    }

    try {
        Connection con = Conexion.conectar();

        String sql = "INSERT INTO manufacturertransaction(ManufacturerID, EmployeeID, TransactionDate, Amount, Reference, Description) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement ps = con.prepareStatement(sql);

        // INT → setInt() + parseInt()
        ps.setInt(1, Integer.parseInt(txtManufacturerID.getText()));
        ps.setInt(2, Integer.parseInt(txtEmployeeID.getText()));

        // DATE → setDate() (formato esperado: yyyy-MM-dd)
        ps.setDate(3, java.sql.Date.valueOf(txtTransactionDate.getText()));

        // DECIMAL → setDouble() + parseDouble()
        ps.setDouble(4, Double.parseDouble(txtAmount.getText()));

        // INT → setInt() + parseInt()
        ps.setInt(5, Integer.parseInt(txtReference.getText()));

        // VARCHAR → setString()
        ps.setString(6, txtDescription.getText());

        int resultado = ps.executeUpdate();

        if (resultado > 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Transacción registrada correctamente");

            txtTransactionID.setText("");
            txtManufacturerID.setText("");
            txtEmployeeID.setText("");
            txtTransactionDate.setText("");
            txtAmount.setText("");
            txtReference.setText("");
            txtDescription.setText("");
        }

    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: Los campos numéricos deben contener solo números válidos.");
    } catch (IllegalArgumentException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: La fecha debe tener el formato yyyy-MM-dd  Ej: 2024-01-25");
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
  

    }//GEN-LAST:event_btnInsertarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed

          try {
        Connection con = Conexion.conectar();

        String sql = "UPDATE manufacturertransaction SET ManufacturerID = ?, EmployeeID = ?, TransactionDate = ?, "
                   + "Amount = ?, Reference = ?, Description = ? "
                   + "WHERE TransactionID = ?";

        PreparedStatement ps = con.prepareStatement(sql);

        // INT → setInt() + parseInt()
        ps.setInt(1, Integer.parseInt(txtManufacturerID.getText()));
        ps.setInt(2, Integer.parseInt(txtEmployeeID.getText()));

        // DATE → setDate() (formato esperado: yyyy-MM-dd)
        ps.setDate(3, java.sql.Date.valueOf(txtTransactionDate.getText()));

        // DECIMAL → setDouble() + parseDouble()
        ps.setDouble(4, Double.parseDouble(txtAmount.getText()));

        // INT → setInt() + parseInt()
        ps.setInt(5, Integer.parseInt(txtReference.getText()));

        // VARCHAR → setString()
        ps.setString(6, txtDescription.getText());

        // WHERE → TransactionID INT
        ps.setInt(7, Integer.parseInt(txtTransactionID.getText()));

        ps.executeUpdate();

        javax.swing.JOptionPane.showMessageDialog(this, "Transacción del fabricante modificada correctamente");

    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: Los campos numéricos deben contener solo números válidos.");
    } catch (IllegalArgumentException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: La fecha debe tener el formato yyyy-MM-dd  Ej: 2024-01-25");
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
        
 
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

         try {
        Connection con = Conexion.conectar();

        String sql = "DELETE FROM manufacturertransaction WHERE TransactionID = ?";
        PreparedStatement ps = con.prepareStatement(sql);

        // INT → setInt() + parseInt()
        ps.setInt(1, Integer.parseInt(txtTransactionID.getText()));
        ps.executeUpdate();

        javax.swing.JOptionPane.showMessageDialog(this, "Transacción eliminada correctamente");

        txtTransactionID.setText("");
        txtManufacturerID.setText("");
        txtEmployeeID.setText("");
        txtTransactionDate.setText("");
        txtAmount.setText("");
        txtReference.setText("");
        txtDescription.setText("");

    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: El ID debe ser un número entero.");
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
        

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

     buscarDatos();
        
    }//GEN-LAST:event_btnBuscarActionPerformed

    public void mostrarDatos() {
    String[] columnas = {
        "TransactionID",
        "ManufacturerID",
        "EmployeeID",
        "TransactionDate",
        "Amount",
        "Reference",
        "Description"
    };
    DefaultTableModel modelo = new DefaultTableModel(null, columnas) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    String sql = "SELECT * FROM manufacturertransaction";
    try {
        Connection con = Conexion.conectar();
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Object[] fila = {
                rs.getInt("TransactionID"),
                rs.getInt("ManufacturerID"),
                rs.getInt("EmployeeID"),
                rs.getDate("TransactionDate"),
                rs.getDouble("Amount"),
                rs.getInt("Reference"),
                rs.getString("Description")
            };
            modelo.addRow(fila);
        }
        tablaManufacturerTransaction.setModel(modelo);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar datos: " + e);
    }
}

public void buscarDatos() {
    String[] columnas = {
        "TransactionID",
        "ManufacturerID",
        "EmployeeID",
        "TransactionDate",
        "Amount",
        "Reference",
        "Description"
    };
    DefaultTableModel modelo = new DefaultTableModel(null, columnas) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    String sql = "SELECT * FROM manufacturertransaction WHERE TransactionID = ?";
    try {
        Connection con = Conexion.conectar();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, txtTransactionID.getText());
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            txtManufacturerID.setText(String.valueOf(rs.getInt("ManufacturerID")));
            txtEmployeeID.setText(String.valueOf(rs.getInt("EmployeeID")));
            txtTransactionDate.setText(String.valueOf(rs.getDate("TransactionDate")));
            txtAmount.setText(String.valueOf(rs.getDouble("Amount")));
            txtReference.setText(String.valueOf(rs.getInt("Reference")));
            txtDescription.setText(rs.getString("Description"));
            Object[] fila = {
                rs.getInt("TransactionID"),
                rs.getInt("ManufacturerID"),
                rs.getInt("EmployeeID"),
                rs.getDate("TransactionDate"),
                rs.getDouble("Amount"),
                rs.getInt("Reference"),
                rs.getString("Description")
            };
            modelo.addRow(fila);
            tablaManufacturerTransaction.setModel(modelo);
        } else {
            JOptionPane.showMessageDialog(this, "Transacción no encontrada");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}
    
    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed

    txtTransactionID.setText("");
    txtManufacturerID.setText("");
    txtEmployeeID.setText("");
    txtTransactionDate.setText("");
    txtAmount.setText("");
    txtReference.setText("");
    txtDescription.setText("");
        
     
    }//GEN-LAST:event_btnLimpiarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManufacturerTransactionCRUD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManufacturerTransactionCRUD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManufacturerTransactionCRUD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManufacturerTransactionCRUD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManufacturerTransactionCRUD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel campoAmount;
    private javax.swing.JLabel campoDescription;
    private javax.swing.JLabel campoEmployeeID;
    private javax.swing.JLabel campoManufacturerID;
    private javax.swing.JLabel campoTransactionDate;
    private javax.swing.JLabel campoTransactionID;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaManufacturerTransaction;
    private javax.swing.JTextField txtAmount;
    private javax.swing.JTextField txtDescription;
    private javax.swing.JTextField txtEmployeeID;
    private javax.swing.JTextField txtManufacturerID;
    private javax.swing.JTextField txtReference;
    private javax.swing.JTextField txtTransactionDate;
    private javax.swing.JTextField txtTransactionID;
    // End of variables declaration//GEN-END:variables
}
